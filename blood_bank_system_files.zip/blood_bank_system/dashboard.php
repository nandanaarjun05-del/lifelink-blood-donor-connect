<?php require_once "auth.php"; ?>
<!DOCTYPE html>
<html><head><title>Dashboard</title><link rel="stylesheet" href="style.css"></head>
<body><div class="dashboard">
<h2>Welcome, <?php echo htmlspecialchars($_SESSION["name"] ?? "User"); ?></h2>
<a href="add_donor.php">Add Donor</a>
<a href="search.php">Search Blood</a>
<a href="view_requests.php">View Requests</a>
<a href="admin_panel.php">Admin Panel (Demo)</a>
<a href="logout.php">Logout</a>
</div></body></html>