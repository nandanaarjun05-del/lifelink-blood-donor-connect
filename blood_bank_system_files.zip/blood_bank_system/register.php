<?php
session_start();
require_once "db.php";
$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    if ($name === "" || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 6) {
        $message = "Enter a valid name/email and a password with at least 6 characters.";
    } else {
        $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $exists = $check->get_result()->num_rows > 0;
        $check->close();

        if ($exists) {
            $message = "This email is already registered.";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $name, $email, $hash);
            if ($stmt->execute()) {
                header("Location: login.php?registered=1");
                exit;
            }
            $message = "Registration failed. Please try again.";
            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html><head><title>Register</title><link rel="stylesheet" href="style.css"></head>
<body><div class="container">
<form method="post">
<h2>Create Account</h2>
<?php if ($message) echo '<p class="message">'.htmlspecialchars($message).'</p>'; ?>
<input type="text" name="name" placeholder="Name" required>
<input type="email" name="email" placeholder="Email" required>
<input type="password" name="password" placeholder="Password (minimum 6 characters)" minlength="6" required>
<button type="submit">Register</button>
<p>Already registered? <a href="login.php">Login</a></p>
</form></div></body></html>