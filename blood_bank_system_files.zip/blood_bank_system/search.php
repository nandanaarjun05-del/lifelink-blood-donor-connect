<?php
require_once "auth.php";
require_once "db.php";
$results = [];
$searched = false;
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $blood = strtoupper(trim($_POST["blood"] ?? ""));
    $hospital = trim($_POST["hospital"] ?? "");
    $stmt = $conn->prepare("SELECT id, name, age, blood_group, hospital, address, phone FROM donors WHERE blood_group = ? AND hospital LIKE ? AND status = 'Available'");
    $hospitalLike = "%" . $hospital . "%";
    $stmt->bind_param("ss", $blood, $hospitalLike);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) $results[] = $row;
    $stmt->close();
    $searched = true;
}
?>
<!DOCTYPE html>
<html><head><title>Search Blood</title><link rel="stylesheet" href="style.css"></head>
<body><div class="container">
<form method="post">
<h2>Find Blood Donor</h2>
<input name="blood" placeholder="Blood Group (e.g. O+)" required>
<input name="hospital" placeholder="Hospital (optional)">
<button type="submit">Search</button>
<a href="dashboard.php">Dashboard</a>
</form></div>
<?php if ($searched): ?>
<div class="table-wrap"><table>
<tr><th>Name</th><th>Age</th><th>Blood</th><th>Hospital</th><th>Address</th><th>Phone</th><th>Request</th></tr>
<?php if (!$results): ?><tr><td colspan="7">No available donors found.</td></tr>
<?php else: foreach ($results as $row): ?>
<tr>
<td><?=htmlspecialchars($row["name"])?></td><td><?=htmlspecialchars($row["age"])?></td>
<td><?=htmlspecialchars($row["blood_group"])?></td><td><?=htmlspecialchars($row["hospital"])?></td>
<td><?=htmlspecialchars($row["address"])?></td><td><?=htmlspecialchars($row["phone"])?></td>
<td><a class="button" href="request.php?id=<?=(int)$row["id"]?>">Request</a></td>
</tr>
<?php endforeach; endif; ?>
</table></div>
<?php endif; ?>
</body></html>