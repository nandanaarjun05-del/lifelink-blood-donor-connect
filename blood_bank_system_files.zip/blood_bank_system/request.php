<?php
require_once "auth.php";
require_once "db.php";
$message = "";
$donorId = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $donorId = (int)($_POST["donor_id"] ?? 0);
    $receiver = trim($_POST["receiver_name"] ?? "");
    $check = $conn->prepare("SELECT id FROM donors WHERE id = ? AND status = 'Available'");
    $check->bind_param("i", $donorId);
    $check->execute();
    $exists = $check->get_result()->num_rows > 0;
    $check->close();

    if (!$exists || $receiver === "") {
        $message = "Please enter a receiver name and choose an available donor.";
    } else {
        $stmt = $conn->prepare("INSERT INTO requests (donor_id, receiver_name, status) VALUES (?, ?, 'Pending')");
        $stmt->bind_param("is", $donorId, $receiver);
        if ($stmt->execute()) {
            $message = "Request sent successfully.";
        } else {
            $message = "Could not send request.";
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html><head><title>Blood Request</title><link rel="stylesheet" href="style.css"></head>
<body><div class="container">
<h2>Send Blood Request</h2>
<?php if ($message): ?><p class="message"><?=htmlspecialchars($message)?></p><?php endif; ?>
<?php if (!$message || strpos($message, "successfully") === false): ?>
<form method="post">
<input type="hidden" name="donor_id" value="<?=(int)$donorId?>">
<input name="receiver_name" placeholder="Receiver Name" required>
<button type="submit">Send Request</button>
</form>
<?php endif; ?>
<a href="search.php">Back to Search</a>
</div></body></html>