<?php
require_once "auth.php";
require_once "db.php";

// Demo project: any logged-in user can use this panel.
// For a real system, add an admin role and restrict this page to admins.
if (isset($_GET["accept"]) || isset($_GET["reject"])) {
    $id = (int)($_GET["accept"] ?? $_GET["reject"]);
    $status = isset($_GET["accept"]) ? "Accepted" : "Rejected";
    $stmt = $conn->prepare("UPDATE requests SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $id);
    $stmt->execute();
    $stmt->close();
    header("Location: admin_panel.php");
    exit;
}
$sql = "SELECT requests.id, requests.receiver_name, requests.status, donors.name AS donor_name, donors.blood_group
        FROM requests JOIN donors ON requests.donor_id = donors.id ORDER BY requests.id DESC";
$res = $conn->query($sql);
?>
<!DOCTYPE html>
<html><head><title>Admin Panel</title><link rel="stylesheet" href="style.css"></head>
<body><h2 style="text-align:center;color:white;">Admin Panel - Blood Requests</h2>
<div class="table-wrap"><table>
<tr><th>ID</th><th>Receiver</th><th>Donor</th><th>Blood</th><th>Status</th><th>Action</th></tr>
<?php if ($res->num_rows === 0): ?><tr><td colspan="6">No requests found.</td></tr>
<?php else: while ($row = $res->fetch_assoc()): ?>
<tr>
<td><?=(int)$row["id"]?></td><td><?=htmlspecialchars($row["receiver_name"])?></td>
<td><?=htmlspecialchars($row["donor_name"])?></td><td><?=htmlspecialchars($row["blood_group"])?></td>
<td><?=htmlspecialchars($row["status"])?></td><td>
<a class="button accept" href="admin_panel.php?accept=<?=(int)$row["id"]?>">Accept</a>
<a class="button reject" href="admin_panel.php?reject=<?=(int)$row["id"]?>" onclick="return confirm('Reject this request?')">Reject</a>
</td></tr>
<?php endwhile; endif; ?>
</table></div><div class="back"><a href="dashboard.php" style="color:white;">Back to Dashboard</a></div>
</body></html>