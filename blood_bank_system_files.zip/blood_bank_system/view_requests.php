<?php
require_once "auth.php";
require_once "db.php";
$sql = "SELECT requests.id, requests.receiver_name, requests.status, donors.name AS donor_name, donors.blood_group
        FROM requests JOIN donors ON requests.donor_id = donors.id ORDER BY requests.id DESC";
$res = $conn->query($sql);
?>
<!DOCTYPE html>
<html><head><title>View Requests</title><link rel="stylesheet" href="style.css"></head>
<body><h2 style="text-align:center;color:white;">Blood Requests</h2>
<div class="table-wrap"><table>
<tr><th>ID</th><th>Receiver Name</th><th>Donor</th><th>Blood Group</th><th>Status</th></tr>
<?php if ($res->num_rows === 0): ?><tr><td colspan="5">No requests found.</td></tr>
<?php else: while ($row = $res->fetch_assoc()): ?>
<tr><td><?=(int)$row["id"]?></td><td><?=htmlspecialchars($row["receiver_name"])?></td>
<td><?=htmlspecialchars($row["donor_name"])?></td><td><?=htmlspecialchars($row["blood_group"])?></td>
<td><?=htmlspecialchars($row["status"])?></td></tr>
<?php endwhile; endif; ?>
</table></div><div class="back"><a href="dashboard.php">Back to Dashboard</a></div>
</body></html>