BLOOD BANK MANAGEMENT SYSTEM (PHP + MySQL)

FILES
- db.php             Database connection
- style.css          Common page styling
- register.php       User registration
- login.php          User login
- dashboard.php      Main dashboard
- add_donor.php      Add donor details
- search.php         Search available donors
- request.php        Send a blood request
- view_requests.php  View submitted requests
- admin_panel.php    Accept/reject requests (demo access)
- logout.php         Logout
- database.sql       Database and table creation

SETUP USING XAMPP
1. Copy the complete blood_bank_system folder into:
   C:\xampp\htdocs\
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open http://localhost/phpmyadmin
4. Select the Import tab and import database.sql.
   This creates the blood_system database and required tables.
5. If your MySQL username/password is different, update db.php.
   Default XAMPP settings are usually username=root and blank password.
6. Open:
   http://localhost/blood_bank_system/register.php
7. Register an account, log in, and use the dashboard.

IMPORTANT
- This is an educational/demo project, not a production blood-bank service.
- The demo admin panel is accessible to every logged-in user. A real system
  should have separate admin accounts and role-based access control.
- Donor eligibility and blood compatibility must be verified by qualified
  medical professionals. Do not use this sample app to make medical decisions.
