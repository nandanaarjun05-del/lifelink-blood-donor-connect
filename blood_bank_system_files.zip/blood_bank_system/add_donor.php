<?php
require_once "auth.php";
require_once "db.php";
$message = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $age = (int)($_POST["age"] ?? 0);
    $blood = strtoupper(trim($_POST["blood"] ?? ""));
    $hospital = trim($_POST["hospital"] ?? "");
    $address = trim($_POST["address"] ?? "");
    $phone = trim($_POST["phone"] ?? "");
    $status = $_POST["status"] ?? "Available";

    $allowed = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
    if ($name === "" || $age < 18 || $age > 65 || !in_array($blood, $allowed, true) ||
        $hospital === "" || $address === "" || $phone === "" ||
        !in_array($status, ["Available", "Not Available"], true)) {
        $message = "Please enter valid donor details. Donor age must be 18–65.";
    } else {
        $stmt = $conn->prepare("INSERT INTO donors (name, age, blood_group, hospital, address, phone, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sisssss", $name, $age, $blood, $hospital, $address, $phone, $status);
        $message = $stmt->execute() ? "Donor details saved successfully." : "Could not save donor details.";
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html><head><title>Add Donor</title><link rel="stylesheet" href="style.css"></head>
<body><div class="container"><form method="post">
<h2>Add Donor</h2>
<?php if ($message) echo '<p class="message">'.htmlspecialchars($message).'</p>'; ?>
<input name="name" placeholder="Name" required>
<input name="age" type="number" min="18" max="65" placeholder="Age" required>
<select name="blood" required>
<option value="">Select Blood Group</option>
<?php foreach (["A+","A-","B+","B-","AB+","AB-","O+","O-"] as $group) echo '<option>'. $group .'</option>'; ?>
</select>
<input name="hospital" placeholder="Hospital" required>
<input name="address" placeholder="Address" required>
<input name="phone" type="tel" placeholder="Phone" required>
<select name="status"><option>Available</option><option>Not Available</option></select>
<button type="submit">Save Donor</button>
<a href="dashboard.php">Dashboard</a>
</form></div></body></html>