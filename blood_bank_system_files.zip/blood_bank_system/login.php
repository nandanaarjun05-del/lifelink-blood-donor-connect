<?php
session_start();
require_once "db.php";
$message = isset($_GET["registered"]) ? "Registration successful. Please log in." : "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    $stmt = $conn->prepare("SELECT id, name, email, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    if ($user && password_verify($password, $user["password"])) {
        session_regenerate_id(true);
        $_SESSION["user_id"] = $user["id"];
        $_SESSION["user"] = $user["email"];
        $_SESSION["name"] = $user["name"];
        header("Location: dashboard.php");
        exit;
    } else {
        $message = "Login failed. Check your email and password.";
    }
}
?>
<!DOCTYPE html>
<html><head><title>Login</title><link rel="stylesheet" href="style.css"></head>
<body><div class="container">
<form method="post">
<h2>Login</h2>
<?php if ($message) echo '<p class="message">'.htmlspecialchars($message).'</p>'; ?>
<input type="email" name="email" placeholder="Email" required>
<input type="password" name="password" placeholder="Password" required>
<button type="submit">Login</button>
<p>New user? <a href="register.php">Register</a></p>
</form></div></body></html>